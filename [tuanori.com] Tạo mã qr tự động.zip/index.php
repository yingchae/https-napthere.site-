<?php
/*CODE API BỞI TUANORI.VN*/
function check_string($data)
{
    return trim(htmlspecialchars(addslashes($data)));
}
if(isset($_POST['submit'])) {
    $name   = check_string($_POST['name']);
    $stk    = check_string($_POST['stk']);
    $money  = check_string($_POST['money']);
    $tentk  = urlencode(check_string($_POST['tentk']));
    $nd     = urlencode(check_string($_POST['nd']));
    $temp   = check_string($_POST['temp']);
    if(!$name) {
        echo 'Bạn chưa chọn ngân hàng';
    } else if(!$stk) {
        echo 'Bạn chưa điền số tài khoản';
    } else {
        // $url = "https://api.vietqr.io/$name/$stk/$money/$nd/vietqr_net_2.jpg";
        $url = "https://img.vietqr.io/image/$name-$stk-$temp.png?amount=$money&addInfo=$nd&accountName=$tentk";
    }
}
function customUrlDecode($value) {
    $value = str_replace('%2B', ' ', $value);
    // Nếu có các quy tắc giải mã khác, bạn có thể thêm vào đây
    return $value;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tạo Mã QR Online - Phạm Hoàng Tuấn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"
          integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <div class="row" style="margin-top: 50px;">
        <div class="col-md-8" style="float:none;margin:0 auto;">
            <form method="POST" action="">
                <div class="form-group">
                    <label>Ngân hàng:</label>
                    <select class="form-control" name="name">
                        <option value="ICB">(970415) VietinBank</option>
                        <option value="VCB">(970436) Vietcombank</option>
                        <option value="BIDV">(970418) BIDV</option>
                        <option value="VBA">(970405) Agribank</option>
                        <option value="OCB">(970448) OCB</option>
                        <option value="MB">(970422) MBBank</option>
                        <option value="TCB">(970407) Techcombank</option>
                        <option value="ACB">(970416) ACB</option>
                        <option value="VPB">(970432) VPBank</option>
                        <option value="TPB">(970423) TPBank</option>
                        <option value="STB">(970403) Sacombank</option>
                        <option value="HDB">(970437) HDBank</option>
                        <option value="VCCB">(970454) VietCapitalBank</option>
                        <option value="SCB">(970429) SCB</option>
                        <option value="VIB">(970441) VIB</option>
                        <option value="SHB">(970443) SHB</option>
                        <option value="EIB">(970431) Eximbank</option>
                        <option value="MSB">(970426) MSB</option>
                        <option value="CAKE">(546034) CAKE</option>
                        <option value="Ubank">(546035) Ubank</option>
                        <option value="TIMO">(963388) Timo</option>
                        <option value="VTLMONEY">(971005) ViettelMoney</option>
                        <option value="VNPTMONEY">(971011) VNPTMoney</option>
                        <option value="SGICB">(970400) SaigonBank</option>
                        <option value="BAB">(970409) BacABank</option>
                        <option value="PVCB">(970412) PVcomBank</option>
                        <option value="Oceanbank">(970414) Oceanbank</option>
                        <option value="NCB">(970419) NCB</option>
                        <option value="SHBVN">(970424) ShinhanBank</option>
                        <option value="ABB">(970425) ABBANK</option>
                        <option value="VAB">(970427) VietABank</option>
                        <option value="NAB">(970428) NamABank</option>
                        <option value="PGB">(970430) PGBank</option>
                        <option value="VIETBANK">(970433) VietBank</option>
                        <option value="BVB">(970438) BaoVietBank</option>
                        <option value="SEAB">(970440) SeABank</option>
                        <option value="COOPBANK">(970446) COOPBANK</option>
                        <option value="LPB">(970449) LienVietPostBank</option>
                        <option value="KLB">(970452) KienLongBank</option>
                        <option value="KBank">(668888) KBank</option>
                        <option value="UOB">(970458) UnitedOverseas</option>
                        <option value="SCVN">(970410) StandardChartered</option>
                        <option value="PBVN">(970439) PublicBank</option>
                        <option value="NHB HN">(801011) Nonghyup</option>
                        <option value="IVB">(970434) IndovinaBank</option>
                        <option value="IBK - HCM">(970456) IBKHCM</option>
                        <option value="IBK - HN">(970455) IBKHN</option>
                        <option value="VRB">(970421) VRB</option>
                        <option value="WVN">(970457) Woori</option>
                        <option value="KBHN">(970462) KookminHN</option>
                        <option value="KBHCM">(970463) KookminHCM</option>
                        <option value="HSBC">(458761) HSBC</option>
                        <option value="HLBVN">(970442) HongLeong</option>
                        <option value="GPB">(970408) GPBank</option>
                        <option value="DOB">(970406) DongABank</option>
                        <option value="DBS">(796500) DBSBank</option>
                        <option value="CIMB">(422589) CIMB</option>
                        <option value="CBB">(970444) CBBank</option>
                        <option value="CITIBANK">(533948) Citibank</option> 
                        <option value="KEBHANAHCM">(970466) KEBHanaHCM</option>
                        <option value="KEBHANAHN">(970467) KEBHANAHN</option>
                        <option value="MAFC">(977777) MAFC</option>
                        <option value="VBSP">(999888) VBSP</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Số tài khoản:</label>
                    <input type="text" class="form-control" name="stk" value="<?php echo (isset($stk) ? $stk : ""); ?>"/>
                </div>
                <div class="form-group">
                    <label>Tên chủ thẻ:</label>
                    <input type="text" class="form-control" name="tentk" value="<?php echo (isset($tentk) ? urldecode($tentk) : ""); ?>"/>
                </div>
                <div class="form-group">
                    <label>Số tiền  mặc định (Không bắt buộc):</label>
                    <input type="number" class="form-control" name="money" value ="<?php echo (isset($money) ? $money : 0); ?>"/>
                </div>
                <div class="form-group">
                    <label>Nội dung mặc định (Không bắt buộc):</label>
                    <input type="text" class="form-control" name="nd" value ="<?php echo (isset($nd) ? urldecode($nd) : ""); ?>"/>
                </div>
                <div class="form-group">
                    <label>Giao diện mã:</label>
                    <select class="form-control" name="temp">
                        <option value="compact">Bao gồm : Mã QR, các logo , thông tin chuyển khoản</option>
                        <option value="compact2">QR kèm logo VietQR, Napas, ngân hàng</option>
                        <option value="qr_only">Trả về ảnh QR đơn giản, chỉ bao gồm QR</option>
                        <option value="print">Bao gồm : Mã QR, các logo và đầy đủ thông tin chuyển khoản</option>
                    </select>
                </div>
        
                <i>MÃ QR có thời hạn dùng là vĩnh viễn</i>
                <div class="form-group">
                    <button type="submit" class="btn btn-success btn-block" name="submit">TẠO MÃ</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php if(isset($url)) { ?>
<center><img src = "<?=$url;?>">
<div class="col-md-1" style="float:none;margin:0 auto;">
    <div class="form-group">
        <a type="submit" class="btn btn-danger btn-block" href="download.php?z=<?=base64_encode($url)?>">DOWNLOAD MÃ</a>
    </div>
</div>
</center>
<?php } ?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"
        integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
        crossorigin="anonymous"></script>
</body>
</html>